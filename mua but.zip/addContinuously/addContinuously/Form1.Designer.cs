﻿namespace addContinuously
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtb_totalMoney = new System.Windows.Forms.TextBox();
            this.lbl_totalMoney = new System.Windows.Forms.Label();
            this.lbl_addNumber = new System.Windows.Forms.Label();
            this.txtb_addNumber = new System.Windows.Forms.TextBox();
            this.lbl_example = new System.Windows.Forms.Label();
            this.btn_next = new System.Windows.Forms.Button();
            this.lbl_currentPrice = new System.Windows.Forms.Label();
            this.txtb_currentPrice = new System.Windows.Forms.TextBox();
            this.lbl_vnd = new System.Windows.Forms.Label();
            this.lbl_vnd2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtb_totalMoney
            // 
            this.txtb_totalMoney.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_totalMoney.Location = new System.Drawing.Point(415, 70);
            this.txtb_totalMoney.Name = "txtb_totalMoney";
            this.txtb_totalMoney.Size = new System.Drawing.Size(100, 31);
            this.txtb_totalMoney.TabIndex = 0;
            // 
            // lbl_totalMoney
            // 
            this.lbl_totalMoney.AutoSize = true;
            this.lbl_totalMoney.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalMoney.Location = new System.Drawing.Point(74, 70);
            this.lbl_totalMoney.Name = "lbl_totalMoney";
            this.lbl_totalMoney.Size = new System.Drawing.Size(329, 25);
            this.lbl_totalMoney.TabIndex = 1;
            this.lbl_totalMoney.Text = "Tổng số tiền đang có (vd: 50000)";
            // 
            // lbl_addNumber
            // 
            this.lbl_addNumber.AutoSize = true;
            this.lbl_addNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_addNumber.Location = new System.Drawing.Point(74, 233);
            this.lbl_addNumber.Name = "lbl_addNumber";
            this.lbl_addNumber.Size = new System.Drawing.Size(296, 25);
            this.lbl_addNumber.TabIndex = 2;
            this.lbl_addNumber.Text = "Số tiền tăng sau mỗi lần mua ";
            // 
            // txtb_addNumber
            // 
            this.txtb_addNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_addNumber.Location = new System.Drawing.Point(415, 227);
            this.txtb_addNumber.Name = "txtb_addNumber";
            this.txtb_addNumber.Size = new System.Drawing.Size(100, 31);
            this.txtb_addNumber.TabIndex = 3;
            // 
            // lbl_example
            // 
            this.lbl_example.AutoSize = true;
            this.lbl_example.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_example.Location = new System.Drawing.Point(74, 258);
            this.lbl_example.Name = "lbl_example";
            this.lbl_example.Size = new System.Drawing.Size(109, 25);
            this.lbl_example.TabIndex = 4;
            this.lbl_example.Text = "(vd: 1000)";
            // 
            // btn_next
            // 
            this.btn_next.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_next.Location = new System.Drawing.Point(549, 301);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(117, 37);
            this.btn_next.TabIndex = 5;
            this.btn_next.Text = "Next";
            this.btn_next.UseVisualStyleBackColor = true;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // lbl_currentPrice
            // 
            this.lbl_currentPrice.AutoSize = true;
            this.lbl_currentPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_currentPrice.Location = new System.Drawing.Point(74, 147);
            this.lbl_currentPrice.Name = "lbl_currentPrice";
            this.lbl_currentPrice.Size = new System.Drawing.Size(271, 25);
            this.lbl_currentPrice.TabIndex = 6;
            this.lbl_currentPrice.Text = "Giá tiền cây bút  (vd: 2000)";
            // 
            // txtb_currentPrice
            // 
            this.txtb_currentPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_currentPrice.Location = new System.Drawing.Point(415, 144);
            this.txtb_currentPrice.Name = "txtb_currentPrice";
            this.txtb_currentPrice.Size = new System.Drawing.Size(100, 31);
            this.txtb_currentPrice.TabIndex = 7;
            // 
            // lbl_vnd
            // 
            this.lbl_vnd.AutoSize = true;
            this.lbl_vnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_vnd.Location = new System.Drawing.Point(521, 73);
            this.lbl_vnd.Name = "lbl_vnd";
            this.lbl_vnd.Size = new System.Drawing.Size(56, 25);
            this.lbl_vnd.TabIndex = 8;
            this.lbl_vnd.Text = "VND";
            // 
            // lbl_vnd2
            // 
            this.lbl_vnd2.AutoSize = true;
            this.lbl_vnd2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_vnd2.Location = new System.Drawing.Point(521, 147);
            this.lbl_vnd2.Name = "lbl_vnd2";
            this.lbl_vnd2.Size = new System.Drawing.Size(56, 25);
            this.lbl_vnd2.TabIndex = 10;
            this.lbl_vnd2.Text = "VND";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(678, 350);
            this.Controls.Add(this.lbl_vnd2);
            this.Controls.Add(this.lbl_vnd);
            this.Controls.Add(this.txtb_currentPrice);
            this.Controls.Add(this.lbl_currentPrice);
            this.Controls.Add(this.btn_next);
            this.Controls.Add(this.lbl_example);
            this.Controls.Add(this.txtb_addNumber);
            this.Controls.Add(this.lbl_addNumber);
            this.Controls.Add(this.lbl_totalMoney);
            this.Controls.Add(this.txtb_totalMoney);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtb_totalMoney;
        private System.Windows.Forms.Label lbl_totalMoney;
        private System.Windows.Forms.Label lbl_addNumber;
        private System.Windows.Forms.TextBox txtb_addNumber;
        private System.Windows.Forms.Label lbl_example;
        private System.Windows.Forms.Button btn_next;
        private System.Windows.Forms.Label lbl_currentPrice;
        private System.Windows.Forms.TextBox txtb_currentPrice;
        private System.Windows.Forms.Label lbl_vnd;
        private System.Windows.Forms.Label lbl_vnd2;
    }
}

