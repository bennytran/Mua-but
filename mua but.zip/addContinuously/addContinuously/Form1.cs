﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace addContinuously
{
    public partial class Form1 : Form
    {
        Form2 form2 = new Form2();
        int initial_money;
        int total_money;
        int initial_number;
        int add_number;
        int initial_price;
        int current_price;
        public Form1()
        {
            InitializeComponent();
        }

        

        private void btn_next_Click(object sender, EventArgs e)
        {
            if ( (int.TryParse(txtb_totalMoney.Text,out int i) && txtb_totalMoney.Text != null) && (int.TryParse(txtb_currentPrice.Text, out int a) && txtb_currentPrice.Text != null)
                && (int.TryParse(txtb_addNumber.Text, out int b) && txtb_addNumber.Text != null) )
                
            {
                initial_money = i;
                total_money = i;
                initial_price = a;
                current_price = a;
                initial_number = b;
                add_number = b;
                int count = 0;

                if (initial_money < initial_price) { MessageBox.Show("Tổng tiền đang có phải lớn hơn giá bút"); }
                else
                {
                    while (total_money >= current_price)
                    {
                        total_money -= current_price;
                        current_price += add_number;
                        count++;
                        form2.txtb_result.Text +=
                            "\nLần mua thứ: " + count +
                            "\nTổng số tiền còn lại: " + total_money + " vnd " +
                            "\nGía tiền cho cây bút kế tiếp: " + current_price + " vnd " +
                            "\n\n"
                            ;
                    }

                    form2.txtb_result2.Text = " Sum: " +
                            "\n Tổng số bút đã mua: " + count +
                            "\n Tổng số tiền ban đầu: " + initial_money + " vnd " +
                            "\n Tiền còn lại: " + total_money + " vnd " +
                            "\n Giá bút ban đầu: " + initial_price + " vnd " +
                            "\n Giá bút hiện tại: " + current_price + " vnd "


                        ;
                    this.Hide();
                    form2.ShowDialog();
                    this.Close();
                }

            }
            else
            {
                MessageBox.Show("Chỉ nhập số");
            }
        }
    }
}
